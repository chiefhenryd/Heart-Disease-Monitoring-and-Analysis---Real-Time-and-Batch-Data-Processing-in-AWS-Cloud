import json
import base64
import boto3
import logging
from decimal import Decimal

# Set up logging
logging.basicConfig(level=logging.INFO)

# SNS ARN for the alert
SNS_ARN = 'arn:aws:sns:eu-west-2:897729140660:Heartdatastream'

def convert_to_decimal(data):
    """Convert float types in data to Decimal types."""
    for key, value in data.items():
        if isinstance(value, float):
            data[key] = Decimal(str(value))  # Convert float to Decimal
    return data

def lambda_handler(event, context):
    # Initialize DynamoDB client
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Heart-data')  # Ensure this matches your actual table name

    # Process each record in the event
    for record in event['Records']:
        # Decode the Kinesis data
        raw_data = record['kinesis']['data']
        logging.info("Raw Kinesis data length: %d", len(raw_data))
        
        try:
            # Correcting the padding for base64 decoding
            padding = len(raw_data) % 4
            if padding > 0:
                raw_data += '=' * (4 - padding)

            # Decode and load JSON
            decoded_data = base64.b64decode(raw_data).decode('utf-8')
            logging.info("Decoded data: %s", decoded_data)
            data = json.loads(decoded_data)

            # Log the full data structure
            logging.info("Data received: %s", data)

            # Convert all float types to Decimal
            data = convert_to_decimal(data)

            # Map patientid to PatientID for DynamoDB
            patient_id = data.pop('patientid', None)  # Extract patientid and remove from data
            if patient_id is None:
                logging.error("PatientID is missing in data: %s", data)
                continue

            data['PatientID'] = patient_id  # Add correct key for DynamoDB

            # Check if blood pressure exceeds thresholds
            systolic_bp = data.get('systolicbp')
            diastolic_bp = data.get('diastolicbp')

            if systolic_bp is not None and diastolic_bp is not None:
                if systolic_bp > Decimal('130') or diastolic_bp > Decimal('80'):
                    # Send SNS alert code here
                    sns_client = boto3.client('sns')
                    alert_message = f"Alert: Patient {patient_id} has high blood pressure: {systolic_bp}/{diastolic_bp}."
                    sns_client.publish(
                        TopicArn=SNS_ARN,
                        Message=alert_message,
                        Subject="High Blood Pressure Alert"
                    )
                    logging.info("Sent alert to SNS: %s", alert_message)

            # Store in DynamoDB
            table.put_item(Item=data)

        except json.JSONDecodeError as e:
            logging.error("JSON Decode Error: %s in payload: %s", str(e), raw_data)
            continue
        except base64.binascii.Error as e:
            logging.error("Base64 Decode Error: %s with raw data: %s", str(e), raw_data)
            continue
        except Exception as e:
            logging.error("Error processing record: %s", str(e))
            continue

    return {
        'statusCode': 200,
        'body': json.dumps("Processed records successfully.")
    }
