import json
import boto3
import random
from datetime import datetime

# Initialize the Kinesis client
kinesis_client = boto3.client('kinesis')

# Replace with your Kinesis Stream name
KINESIS_STREAM_NAME = 'Heart_data'

def send_data_to_kinesis():
    records = []
    
    for _ in range(100):
        # Generate a random patient ID
        patient_id = f"patient_{random.randint(1, 15000)}"

        # Generate random health data
        health_data = {
            "PatientID": "patient_123",  # Updated to match DynamoDB schema
            "heartrate": round(random.uniform(60.0, 120.0), 1),
            "systolicbp": round(random.uniform(90.0, 180.0), 1),
            "diastolicbp": round(random.uniform(60.0, 120.0), 1),
            "timestamp": datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
        }

        # Prepare the record for Kinesis
        records.append({
            'Data': json.dumps(health_data),
            'PartitionKey': patient_id
        })

    try:
        # Send all records to Kinesis in a single batch request
        response = kinesis_client.put_records(
            Records=records,
            StreamName=KINESIS_STREAM_NAME
        )
        # Check for failed records
        failed_record_count = response.get('FailedRecordCount', 0)
        if failed_record_count > 0:
            print(f"Failed to send {failed_record_count} records to Kinesis.")

    except Exception as e:
        print(f"Error sending records to Kinesis: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps('Error sending records to Kinesis.')
        }

    return {
        'statusCode': 200,
        'body': json.dumps('100 records sent to Kinesis.')
    }

def lambda_handler(event, context):
    # Call the function to send data to Kinesis
    return send_data_to_kinesis()
