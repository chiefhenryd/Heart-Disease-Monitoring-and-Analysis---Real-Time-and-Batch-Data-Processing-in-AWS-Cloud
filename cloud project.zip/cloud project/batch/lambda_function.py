import json
import boto3
from datetime import datetime
from faker import Faker
import random

def lambda_handler(event, context):
    fake = Faker()
    client = boto3.client('s3')
    bucket_name = "heartpatient-project"
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    data = []

    # List of real heart disease medications
    heart_disease_medications = [
        'Aspirin', 'Atorvastatin', 'Metoprolol', 'Lisinopril', 'Clopidogrel',
        'Carvedilol', 'Simvastatin', 'Warfarin', 'Digoxin', 'Furosemide'
    ]

    # Generate 1000 fake patient records
    for _ in range(1000):
        heart_disease = fake.boolean()  # Randomly assign Heart Disease status
        patient_record = {
            "Patient ID": fake.unique.random_int(min=5001, max=50000),
            "HeartDisease": "Yes" if heart_disease else "No",
            "BMI": round(fake.random_number(digits=2) + 10, 1),
            "Smoking": "Yes" if (heart_disease and random.choice([True, False])) else "No",
            "AlcoholDrinking": "Yes" if (heart_disease and random.choice([True, False])) else "No",
            "Stroke": "Yes" if (heart_disease and random.choice([True, False])) else "No",
            "PhysicalHealth": fake.random_int(min=0, max=30),
            "MentalHealth": fake.random_int(min=0, max=30),
            "DiffWalking": "Yes" if fake.boolean() else "No",
            "Gender": fake.random_element(elements=('Male', 'Female')),
            "AgeCategory": fake.random_element(elements=('0-17', '18-24', '25-34', '35-44', '45-54', '55-64', '65+')),
            "Race": fake.random_element(elements=('White', 'Black', 'Asian', 'Hispanic')),
            "Diabetic": "Yes" if (heart_disease and random.choice([True, False])) else "No",
            "PhysicalActivity": "Yes" if (not heart_disease and fake.boolean()) else "No",
            "GenHealth": fake.random_element(elements=('Excellent', 'Very good', 'Good', 'Fair', 'Poor')),
            "SleepTime": fake.random_int(min=4, max=12),
            "Asthma": "Yes" if fake.boolean() else "No",
            "KidneyDisease": "Yes" if (heart_disease and random.choice([True, False])) else "No",
            "SkinCancer": "Yes" if fake.boolean() else "No",
            "Age": fake.random_int(min=1, max=100),
            "DateOfLastUpdate": str(datetime.now()),
            "City": fake.city(),
            "State": fake.state(),
            "Country": "USA",
            "PrescribedMedication": random.choice(heart_disease_medications) if heart_disease else "None",
            "MedicalHistory": fake.sentence(),
            "Timestamp": str(datetime.now())
        }
        data.append(patient_record)

    # Create a filename based on the current timestamp
    filename = f"incremental_load_{timestamp}.json"

    # Save the data to S3
    client.put_object(
        Bucket=bucket_name,
        Key=f"rawbronze/incremental_load/{filename}",
        Body=json.dumps(data)
    )

    return {
        'statusCode': 200,
        'body': json.dumps('Incremental load ingestion completed')
    }
