import json
import boto3
import pandas as pd
from datetime import datetime
from io import StringIO

def lambda_handler(event, context):
    client = boto3.client('s3')
    bucket_name = "heartpatient-project"
    staging_folder = "stagingsilver/"

    # Step 1: Retrieve the full load file
    full_load_key = "rawbronze/full_load/full_load_20241028232220.json"  # Use the specified filename
    try:
        full_load_response = client.get_object(Bucket=bucket_name, Key=full_load_key)
        full_load_data = json.loads(full_load_response['Body'].read().decode('utf-8'))
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error retrieving full load file: {str(e)}')
        }

    # Step 2: Retrieve all incremental load files
    incremental_loads = []
    paginator = client.get_paginator('list_objects_v2')
    for page in paginator.paginate(Bucket=bucket_name, Prefix='rawbronze/incremental_load/'):
        for obj in page.get('Contents', []):
            key = obj['Key']
            try:
                incremental_response = client.get_object(Bucket=bucket_name, Key=key)
                incremental_data = json.loads(incremental_response['Body'].read().decode('utf-8'))
                incremental_loads.extend(incremental_data)
            except Exception as e:
                print(f'Error retrieving incremental load file {key}: {str(e)}')  # Log the error

    # Step 3: Merge the full load data with the incremental load data
    merged_data = full_load_data + incremental_loads

    # Step 4: Save the merged data to the stagingsilver folder as CSV
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    merged_filename = f"merged_load_{timestamp}.csv"
    
    try:
        # Convert merged data to DataFrame and then to CSV
        df = pd.DataFrame(merged_data)
        csv_buffer = StringIO()
        df.to_csv(csv_buffer, index=False)
        csv_buffer.seek(0)  # Move to the beginning of the StringIO buffer

        client.put_object(
            Bucket=bucket_name,
            Key=f"{staging_folder}{merged_filename}",
            Body=csv_buffer.getvalue()
        )
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error saving merged data: {str(e)}')
        }

    return {
        'statusCode': 200,
        'body': json.dumps('Merged data ingestion completed')
    }
